#ifndef RECV_FROM_H_
#define RECV_FROM_H_

void recv_from();

#endif
