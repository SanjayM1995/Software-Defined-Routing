#ifndef SEND_UPDATE_H_
#define SEND_UPDATE_H_
#include "../include/init_response.h"

void send_update(int sock_index,int flag);

#endif
