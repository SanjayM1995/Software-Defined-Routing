#ifndef UPDATE_TABLE_H_
#define UPDATE_TABLE_H_

void update_table(int sock_index,char* cntrl_payload);

#endif
